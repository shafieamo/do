from django.contrib import admin
from .models import Droplet

admin.site.register(Droplet)
