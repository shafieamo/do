from django.apps import AppConfig


class DropletConfig(AppConfig):
    name = 'droplet'
