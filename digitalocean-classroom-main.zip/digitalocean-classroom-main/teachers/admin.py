from django.contrib import admin
from teachers.models import Teacher

admin.site.register(Teacher)
# Register your models here.
